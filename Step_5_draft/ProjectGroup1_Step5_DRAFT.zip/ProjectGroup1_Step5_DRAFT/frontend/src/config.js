const backendPort = 7016;  // Change this as needed
export const backendURL = `http://classwork.engr.oregonstate.edu:${backendPort}`;